jnr-enxio
=========

Native I/O access for java

Check out the [examples](https://github.com/jnr/jnr-enxio/tree/master/src/test/java/jnr/enxio/example) for more information.
